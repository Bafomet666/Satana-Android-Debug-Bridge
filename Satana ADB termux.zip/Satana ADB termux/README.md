# Satana sploit

  Я как создатель не несу не какой ответственности. Сделано чисто в образовательных целях
    
# Запускать
 
  python3 SatanaADB.py
 
## Установка
  
  cd Satana ADB
  и сразу запуск
  python3 SatanaADB.py

## Обязательно к установке


Если найдешь способ лучше, я о установке adb на термукс. Буду рад добавить сюда эту информацию.

 Копируете всю строку и вставляете в termux:

  apt update > /dev/null 2>&1 && apt --assume-yes install wget > /dev/null 2>&1 && wget https://github.com/MasterDevX/Termux-ADB/raw/master/InstallTools.sh -q && bash InstallTools.sh
  
 После установки запускаете сервер:

 Запуск сервера:     adb tcpip 5555

 Остановка сервера : adb kill-server 
 
 Список устройств :  adb devices -l
  
## некоторые функции могут не работать.


How to install

    Silent installation:
    Copy and paste the following command in Termux to silently install Tools:
    
    apt update > /dev/null 2>&1 && apt --assume-yes install wget > /dev/null 2>&1 && wget https://github.com/MasterDevX/Termux-ADB/raw/master/InstallTools.sh -q && bash InstallTools.sh
    
    Common installation:
    
    Copy and paste the following command in Termux to install Tools with logs output:
    apt update && apt install wget && wget https://github.com/MasterDevX/Termux-ADB/raw/master/InstallTools.sh && bash InstallTools.sh


